#!/bin/sh

sudo ip a d 192.168.99.180 dev lo
sudo ip a a 192.168.99.181 dev lo
