#!/bin/sh

ip a d 192.168.99.180 dev lo
ip a a 192.168.99.181 dev lo
